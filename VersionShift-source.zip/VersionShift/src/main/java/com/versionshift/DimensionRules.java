package com.versionshift;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.Map;

public final class DimensionRules {
    private static List<? extends String> lastRaw;
    private static Map<String, GameVersion> rules = Map.of();

    private DimensionRules() {}

    /** True if the dimension exists in the given version. The Overworld always exists. */
    public static boolean isAllowed(ResourceKey<Level> dimension, GameVersion version) {
        if (dimension.equals(Level.OVERWORLD)) return true;
        List<? extends String> raw = VSConfig.DIMENSION_RULES.get();
        if (raw != lastRaw) {
            lastRaw = raw;
            rules = VSConfig.parseRules(raw);
        }
        GameVersion since = rules.get(dimension.location().toString());
        return since == null || !since.isNewerThan(version);
    }
}
