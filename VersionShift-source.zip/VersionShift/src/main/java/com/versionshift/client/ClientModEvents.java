package com.versionshift.client;

import com.versionshift.VSConfig;
import com.versionshift.VersionShiftMod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = VersionShiftMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("hud", (gui, graphics, partialTick, width, height) -> {
            if (!VSConfig.SHOW_HUD.get() || !ClientState.active) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui) return;

            int secs = Math.max(0, ClientState.ticksLeft / 20);
            String time = ClientState.paused ? "||" : String.format("%d:%02d", secs / 60, secs % 60);
            Component text = Component.translatable("versionshift.hud", ClientState.version.id(), time);
            int x = (width - mc.font.width(text)) / 2;
            graphics.drawString(mc.font, text, x, 4, 0xFFFFFF);
        });
    }
}
