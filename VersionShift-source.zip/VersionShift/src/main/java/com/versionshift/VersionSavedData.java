package com.versionshift;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Per-world state: current version and the timer. Stored in the Overworld's data folder. */
public class VersionSavedData extends SavedData {
    private static final String ID = "versionshift";

    public GameVersion current = GameVersion.LATEST;
    public int ticksLeft = -1;
    public boolean paused = false;

    public static VersionSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(VersionSavedData::load, VersionSavedData::new, ID);
    }

    public static VersionSavedData load(CompoundTag tag) {
        VersionSavedData data = new VersionSavedData();
        GameVersion v = GameVersion.byId(tag.getString("version"));
        if (v != null) data.current = v;
        data.ticksLeft = tag.contains("ticksLeft") ? tag.getInt("ticksLeft") : -1;
        data.paused = tag.getBoolean("paused");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putString("version", current.id());
        tag.putInt("ticksLeft", ticksLeft);
        tag.putBoolean("paused", paused);
        return tag;
    }
}
