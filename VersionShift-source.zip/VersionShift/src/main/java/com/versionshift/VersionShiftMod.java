package com.versionshift;

import com.mojang.logging.LogUtils;
import com.versionshift.network.Net;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(VersionShiftMod.MODID)
public class VersionShiftMod {
    public static final String MODID = "versionshift";
    public static final Logger LOGGER = LogUtils.getLogger();

    public VersionShiftMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, VSConfig.COMMON_SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, VSConfig.CLIENT_SPEC);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(Net::register);
    }
}
