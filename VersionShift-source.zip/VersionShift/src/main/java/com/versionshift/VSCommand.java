package com.versionshift;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;

public final class VSCommand {
    private VSCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("versionshift")
                .executes(VSCommand::status)
                .then(Commands.literal("status").executes(VSCommand::status))
                .then(Commands.literal("set")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.argument("version", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(GameVersion.ids(), builder))
                                .executes(VSCommand::set)))
                .then(Commands.literal("next")
                        .requires(src -> src.hasPermission(2))
                        .executes(VSCommand::next))
                .then(Commands.literal("pause")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> pause(ctx, true)))
                .then(Commands.literal("resume")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> pause(ctx, false))));
    }

    private static int status(CommandContext<CommandSourceStack> ctx) {
        MinecraftServer server = ctx.getSource().getServer();
        VersionSavedData data = VersionSavedData.get(server);
        Object suffix = data.paused ? Component.translatable("versionshift.cmd.paused") : "";
        Component msg = Component.translatable("versionshift.cmd.status",
                data.current.id(), Math.max(0, data.ticksLeft / 20), suffix);
        ctx.getSource().sendSuccess(() -> msg, false);
        return 1;
    }

    private static int set(CommandContext<CommandSourceStack> ctx) {
        String id = StringArgumentType.getString(ctx, "version");
        GameVersion version = GameVersion.byId(id);
        if (version == null) {
            ctx.getSource().sendFailure(Component.translatable("versionshift.cmd.unknown", id));
            return 0;
        }
        VersionManager.switchTo(ctx.getSource().getServer(), version);
        return 1;
    }

    private static int next(CommandContext<CommandSourceStack> ctx) {
        MinecraftServer server = ctx.getSource().getServer();
        VersionManager.switchTo(server, VersionManager.pickNext(VersionSavedData.get(server).current));
        return 1;
    }

    private static int pause(CommandContext<CommandSourceStack> ctx, boolean paused) {
        MinecraftServer server = ctx.getSource().getServer();
        VersionSavedData data = VersionSavedData.get(server);
        data.paused = paused;
        data.setDirty();
        VersionManager.syncAll(server, data);
        ctx.getSource().sendSuccess(() -> Component.translatable(
                paused ? "versionshift.cmd.pause" : "versionshift.cmd.resume"), true);
        return 1;
    }
}
