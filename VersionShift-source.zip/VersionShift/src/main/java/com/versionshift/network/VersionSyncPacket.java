package com.versionshift.network;

import com.versionshift.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server to client: current version, ticks until the next change, and whether the timer is paused. */
public record VersionSyncPacket(String versionId, int ticksLeft, boolean paused) {

    public static void encode(VersionSyncPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.versionId());
        buf.writeVarInt(msg.ticksLeft());
        buf.writeBoolean(msg.paused());
    }

    public static VersionSyncPacket decode(FriendlyByteBuf buf) {
        return new VersionSyncPacket(buf.readUtf(), buf.readVarInt(), buf.readBoolean());
    }

    public static void handle(VersionSyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientState.apply(msg.versionId(), msg.ticksLeft(), msg.paused())));
        ctx.get().setPacketHandled(true);
    }
}
