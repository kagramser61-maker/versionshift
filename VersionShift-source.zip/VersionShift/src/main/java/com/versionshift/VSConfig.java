package com.versionshift;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class VSConfig {
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final ForgeConfigSpec CLIENT_SPEC;

    // ---- common (server side) ----
    public static final ForgeConfigSpec.IntValue INTERVAL_SECONDS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> VERSIONS;
    public static final ForgeConfigSpec.EnumValue<ItemScope> ITEM_SCOPE;
    public static final ForgeConfigSpec.BooleanValue KEEP_SWEEPING;
    public static final ForgeConfigSpec.BooleanValue BLOCK_PICKUP;
    public static final ForgeConfigSpec.BooleanValue NOTIFY;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> ITEM_RULES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DIMENSION_RULES;

    // ---- client ----
    public static final ForgeConfigSpec.BooleanValue SWAP_TEXTURES;
    public static final ForgeConfigSpec.BooleanValue SHOW_HUD;
    public static final ForgeConfigSpec.ConfigValue<String> LEGACY_MAX_VERSION;
    public static final ForgeConfigSpec.ConfigValue<String> LEGACY_PACK;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> PACK_RULES;

    static {
        ForgeConfigSpec.Builder c = new ForgeConfigSpec.Builder();
        INTERVAL_SECONDS = c
                .comment("How often the game version changes, in seconds (300 = 5 minutes).")
                .defineInRange("intervalSeconds", 300, 5, 86400);
        VERSIONS = c
                .comment("Versions used in the rotation (at least two). Allowed: " + String.join(", ", GameVersion.ids()))
                .defineListAllowEmpty("versions", GameVersion.ids(), o -> o instanceof String);
        ITEM_SCOPE = c
                .comment("Where items from newer versions vanish: HANDS, INVENTORY or INVENTORY_AND_ENDER_CHEST.")
                .defineEnum("itemScope", ItemScope.INVENTORY);
        KEEP_SWEEPING = c
                .comment("Keep removing items that do not exist in the current version once per second",
                        "(covers crafting, creative menu, chests, trades). If false, only the moment of the switch counts.")
                .define("keepSweeping", true);
        BLOCK_PICKUP = c
                .comment("Players cannot pick up item entities that do not exist in the current version.")
                .define("blockPickup", true);
        NOTIFY = c
                .comment("Tell the player when items vanished.")
                .define("notify", true);
        ITEM_RULES = c
                .comment("Extra item rules: \"modid:item=1.12.2\" or \"modid:*=1.12.2\" (first version where the item exists).",
                        "Items that are not listed here and not in the built-in vanilla table exist in every version.")
                .defineListAllowEmpty("itemRules", List.of(), o -> o instanceof String);
        DIMENSION_RULES = c
                .comment("Dimension rules: \"modid:dimension=1.12.2\" (first version where the dimension exists).",
                        "Players inside a dimension that does not exist yet are sent to the Overworld.",
                        "Vanilla Overworld, Nether and End exist in every version from 1.7.10, so only modded dimensions need rules.",
                        "Example: \"twilightforest:twilight_forest=1.12.2\"")
                .defineListAllowEmpty("dimensionRules", List.of(), o -> o instanceof String);
        COMMON_SPEC = c.build();

        ForgeConfigSpec.Builder k = new ForgeConfigSpec.Builder();
        SWAP_TEXTURES = k
                .comment("Swap textures to match the current version.")
                .define("swapTextures", true);
        SHOW_HUD = k
                .comment("Show current version and countdown in the top-left corner.")
                .define("showHud", true);
        LEGACY_MAX_VERSION = k
                .comment("Versions up to and including this one use the legacy pack below.")
                .define("legacyUpToVersion", "1.13.2");
        LEGACY_PACK = k
                .comment("Pack id used for old versions. Default is the built-in \"Programmer Art\" pack (the pre-1.14 look).")
                .define("legacyPack", "programmer_art");
        PACK_RULES = k
                .comment("Per-version pack overrides: \"1.7.10=file/MyOldTextures.zip\" (pack from the resourcepacks folder).",
                        "An empty value (\"1.20.1=\") means vanilla textures for that version.")
                .defineListAllowEmpty("packRules", List.of(), o -> o instanceof String);
        CLIENT_SPEC = k.build();
    }

    private VSConfig() {}

    public static int intervalTicks() {
        return INTERVAL_SECONDS.get() * 20;
    }

    /** Parses entries like "key=1.12.2" into a map (keys are lower-cased). */
    public static Map<String, GameVersion> parseRules(List<? extends String> raw) {
        Map<String, GameVersion> map = new HashMap<>();
        for (String entry : raw) {
            int eq = entry.lastIndexOf('=');
            if (eq <= 0) continue;
            GameVersion v = GameVersion.byId(entry.substring(eq + 1));
            if (v == null) continue;
            map.put(entry.substring(0, eq).trim().toLowerCase(Locale.ROOT), v);
        }
        return map;
    }
}
