package com.versionshift.client;

import com.versionshift.GameVersion;
import net.minecraft.client.Minecraft;

/** What the client currently knows about the server's version clock. */
public final class ClientState {
    public static GameVersion version = GameVersion.LATEST;
    public static int ticksLeft = -1;
    public static boolean paused;
    /** True while connected to a world that runs Version Shift. */
    public static boolean active;

    private ClientState() {}

    public static void apply(String versionId, int ticks, boolean isPaused) {
        GameVersion v = GameVersion.byId(versionId);
        if (v == null) return;
        version = v;
        ticksLeft = ticks;
        paused = isPaused;
        active = true;
        TextureSwitcher.update(v);
    }

    /** Client tick: counts the HUD timer down and restores the normal look after leaving the world. */
    public static void tick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            active = false;
            ticksLeft = -1;
            TextureSwitcher.revert();
            return;
        }
        if (!paused && ticksLeft > 0 && !mc.isPaused()) ticksLeft--;
    }
}
