package com.versionshift;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.versionshift.GameVersion.*;

/**
 * Knows in which version each vanilla item first appeared.
 * Items that appeared in 1.19.3 - 1.20.1 are assigned to 1.20.1, 1.17 to 1.17.1 and so on
 * (the first version of the rotation that contains them). Anything not listed exists everywhere.
 */
public final class ItemRules {
    private static final Map<String, GameVersion> BUILTIN = new HashMap<>();
    private static final Map<Item, GameVersion> CACHE = new HashMap<>();
    private static List<? extends String> lastRaw;
    private static Map<String, GameVersion> overrides = Map.of();

    private static final String[] COLORS = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
            "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
    private static final String[] OLD_WOODS = {"spruce", "birch", "jungle", "acacia", "dark_oak"};

    private static void add(GameVersion v, String... paths) {
        for (String p : paths) BUILTIN.put(p, v);
    }

    static {
        // ---------------- 1.8 ----------------
        add(V1_8_9, "slime_block", "sea_lantern", "prismarine", "prismarine_bricks", "dark_prismarine",
                "prismarine_shard", "prismarine_crystals", "red_sandstone", "chiseled_red_sandstone", "cut_red_sandstone",
                "red_sandstone_stairs", "red_sandstone_slab", "granite", "polished_granite", "diorite", "polished_diorite",
                "andesite", "polished_andesite", "coarse_dirt", "iron_trapdoor", "armor_stand", "barrier", "wet_sponge",
                "mutton", "cooked_mutton", "rabbit", "cooked_rabbit", "rabbit_stew", "rabbit_foot", "rabbit_hide",
                "endermite_spawn_egg", "guardian_spawn_egg", "rabbit_spawn_egg");
        for (String c : COLORS) add(V1_8_9, c + "_banner");
        for (String w : OLD_WOODS) add(V1_8_9, w + "_door", w + "_fence", w + "_fence_gate");

        // ---------------- 1.9 ----------------
        add(V1_9_4, "end_rod", "chorus_plant", "chorus_flower", "chorus_fruit", "popped_chorus_fruit", "purpur_block",
                "purpur_pillar", "purpur_stairs", "purpur_slab", "end_stone_bricks", "end_crystal", "dragon_breath", "elytra",
                "shield", "spectral_arrow", "tipped_arrow", "lingering_potion", "shulker_shell", "shulker_spawn_egg",
                "dragon_head", "dirt_path", "beetroot", "beetroot_seeds", "beetroot_soup", "chain_command_block",
                "repeating_command_block", "structure_block");
        for (String w : OLD_WOODS) add(V1_9_4, w + "_boat");

        // ---------------- 1.10 ----------------
        add(V1_10_2, "magma_block", "nether_wart_block", "red_nether_bricks", "bone_block", "structure_void",
                "polar_bear_spawn_egg", "husk_spawn_egg", "stray_spawn_egg");

        // ---------------- 1.11 ----------------
        add(V1_11_2, "totem_of_undying", "observer", "iron_nugget", "shulker_box", "wither_skeleton_spawn_egg",
                "zombie_villager_spawn_egg", "skeleton_horse_spawn_egg", "zombie_horse_spawn_egg", "donkey_spawn_egg",
                "mule_spawn_egg", "evoker_spawn_egg", "vex_spawn_egg", "vindicator_spawn_egg", "llama_spawn_egg",
                "elder_guardian_spawn_egg");
        for (String c : COLORS) add(V1_11_2, c + "_shulker_box");

        // ---------------- 1.12 ----------------
        add(V1_12_2, "knowledge_book", "parrot_spawn_egg", "illusioner_spawn_egg");
        for (String c : COLORS) {
            add(V1_12_2, c + "_concrete", c + "_concrete_powder", c + "_glazed_terracotta");
            if (!c.equals("red")) add(V1_12_2, c + "_bed"); // the red bed is the old plain bed
        }

        // ---------------- 1.13 ----------------
        for (String c : new String[]{"tube", "brain", "bubble", "fire", "horn"}) {
            add(V1_13_2, c + "_coral", c + "_coral_block", c + "_coral_fan",
                    "dead_" + c + "_coral", "dead_" + c + "_coral_block", "dead_" + c + "_coral_fan");
        }
        add(V1_13_2, "kelp", "dried_kelp", "dried_kelp_block", "seagrass", "sea_pickle", "turtle_egg", "turtle_helmet", "scute",
                "heart_of_the_sea", "nautilus_shell", "conduit", "phantom_membrane", "trident", "blue_ice", "debug_stick",
                "cod_bucket", "salmon_bucket", "pufferfish_bucket", "tropical_fish_bucket",
                "cod_spawn_egg", "salmon_spawn_egg", "pufferfish_spawn_egg", "tropical_fish_spawn_egg", "drowned_spawn_egg",
                "dolphin_spawn_egg", "turtle_spawn_egg", "phantom_spawn_egg",
                "prismarine_stairs", "prismarine_brick_stairs", "dark_prismarine_stairs",
                "prismarine_slab", "prismarine_brick_slab", "dark_prismarine_slab",
                "oak_wood", "stripped_oak_log", "stripped_oak_wood");
        for (String w : OLD_WOODS) {
            add(V1_13_2, w + "_wood", "stripped_" + w + "_log", "stripped_" + w + "_wood",
                    w + "_button", w + "_pressure_plate", w + "_trapdoor");
        }

        // ---------------- 1.14 ----------------
        add(V1_14_4, "barrel", "blast_furnace", "smoker", "cartography_table", "fletching_table", "grindstone", "lectern",
                "loom", "smithing_table", "stonecutter", "composter", "bell", "lantern", "campfire", "scaffolding", "jigsaw",
                "bamboo", "sweet_berries", "cornflower", "lily_of_the_valley", "wither_rose", "suspicious_stew", "crossbow",
                "leather_horse_armor", "creeper_banner_pattern", "skull_banner_pattern", "flower_banner_pattern",
                "mojang_banner_pattern", "black_dye", "blue_dye", "brown_dye", "white_dye",
                "cat_spawn_egg", "fox_spawn_egg", "panda_spawn_egg", "pillager_spawn_egg", "ravager_spawn_egg",
                "wandering_trader_spawn_egg", "trader_llama_spawn_egg",
                "brick_wall", "granite_wall", "diorite_wall", "andesite_wall", "prismarine_wall", "stone_brick_wall",
                "mossy_stone_brick_wall", "nether_brick_wall", "red_nether_brick_wall", "sandstone_wall",
                "red_sandstone_wall", "end_stone_brick_wall",
                "smooth_stone", "smooth_sandstone", "smooth_red_sandstone", "smooth_quartz",
                "stone_stairs", "granite_stairs", "polished_granite_stairs", "diorite_stairs", "polished_diorite_stairs",
                "andesite_stairs", "polished_andesite_stairs", "mossy_cobblestone_stairs", "mossy_stone_brick_stairs",
                "smooth_sandstone_stairs", "smooth_red_sandstone_stairs", "smooth_quartz_stairs", "red_nether_brick_stairs",
                "end_stone_brick_stairs",
                "smooth_stone_slab", "granite_slab", "polished_granite_slab", "diorite_slab", "polished_diorite_slab",
                "andesite_slab", "polished_andesite_slab", "mossy_cobblestone_slab", "mossy_stone_brick_slab",
                "smooth_sandstone_slab", "smooth_red_sandstone_slab", "smooth_quartz_slab", "cut_sandstone_slab",
                "cut_red_sandstone_slab", "red_nether_brick_slab", "end_stone_brick_slab");
        for (String w : OLD_WOODS) add(V1_14_4, w + "_sign");

        // ---------------- 1.15 ----------------
        add(V1_15_2, "bee_nest", "beehive", "honey_block", "honeycomb_block", "honey_bottle", "honeycomb", "bee_spawn_egg");

        // ---------------- 1.16 ----------------
        add(V1_16_5, "ancient_debris", "netherite_block", "netherite_ingot", "netherite_scrap", "netherite_sword",
                "netherite_pickaxe", "netherite_axe", "netherite_shovel", "netherite_hoe", "netherite_helmet",
                "netherite_chestplate", "netherite_leggings", "netherite_boots",
                "basalt", "polished_basalt", "blackstone", "blackstone_slab", "blackstone_stairs", "blackstone_wall",
                "polished_blackstone", "polished_blackstone_slab", "polished_blackstone_stairs", "polished_blackstone_wall",
                "chiseled_polished_blackstone", "polished_blackstone_bricks", "polished_blackstone_brick_slab",
                "polished_blackstone_brick_stairs", "polished_blackstone_brick_wall", "cracked_polished_blackstone_bricks",
                "gilded_blackstone", "polished_blackstone_button", "polished_blackstone_pressure_plate",
                "crying_obsidian", "respawn_anchor", "lodestone", "target", "chain", "shroomlight", "soul_soil",
                "soul_torch", "soul_lantern", "soul_campfire", "nether_gold_ore", "nether_sprouts", "cracked_nether_bricks",
                "chiseled_nether_bricks", "quartz_bricks", "weeping_vines", "twisting_vines", "warped_wart_block",
                "crimson_fungus", "warped_fungus", "crimson_roots", "warped_roots", "crimson_nylium", "warped_nylium",
                "warped_fungus_on_a_stick", "music_disc_pigstep", "piglin_banner_pattern", "globe_banner_pattern",
                "strider_spawn_egg", "hoglin_spawn_egg", "piglin_spawn_egg", "piglin_brute_spawn_egg", "zoglin_spawn_egg");
        for (String f : new String[]{"crimson", "warped"}) {
            add(V1_16_5, f + "_stem", "stripped_" + f + "_stem", f + "_hyphae", "stripped_" + f + "_hyphae",
                    f + "_planks", f + "_slab", f + "_stairs", f + "_fence", f + "_fence_gate", f + "_door",
                    f + "_trapdoor", f + "_button", f + "_pressure_plate", f + "_sign");
        }

        // ---------------- 1.17 ----------------
        add(V1_17_1, "amethyst_block", "budding_amethyst", "amethyst_cluster", "large_amethyst_bud", "medium_amethyst_bud",
                "small_amethyst_bud", "amethyst_shard", "tinted_glass", "calcite", "tuff", "dripstone_block",
                "pointed_dripstone", "smooth_basalt", "copper_ore", "deepslate_copper_ore", "raw_copper", "raw_iron",
                "raw_gold", "raw_copper_block", "raw_iron_block", "raw_gold_block", "copper_ingot", "copper_block",
                "exposed_copper", "weathered_copper", "oxidized_copper", "waxed_copper_block", "waxed_exposed_copper",
                "waxed_weathered_copper", "waxed_oxidized_copper", "lightning_rod", "spyglass", "glow_item_frame",
                "glow_ink_sac", "bundle", "candle", "deepslate", "cobbled_deepslate", "polished_deepslate",
                "deepslate_bricks", "deepslate_tiles", "chiseled_deepslate", "cracked_deepslate_bricks",
                "cracked_deepslate_tiles", "infested_deepslate", "deepslate_coal_ore", "deepslate_iron_ore",
                "deepslate_gold_ore", "deepslate_redstone_ore", "deepslate_emerald_ore", "deepslate_lapis_ore",
                "deepslate_diamond_ore", "rooted_dirt", "hanging_roots", "moss_block", "moss_carpet", "azalea",
                "flowering_azalea", "azalea_leaves", "flowering_azalea_leaves", "big_dripleaf", "small_dripleaf",
                "spore_blossom", "glow_lichen", "glow_berries", "sculk_sensor", "light", "powder_snow_bucket",
                "axolotl_bucket", "axolotl_spawn_egg", "goat_spawn_egg", "glow_squid_spawn_egg");
        for (String c : COLORS) add(V1_17_1, c + "_candle");
        for (String o : new String[]{"", "exposed_", "weathered_", "oxidized_"}) {
            add(V1_17_1, o + "cut_copper", o + "cut_copper_stairs", o + "cut_copper_slab",
                    "waxed_" + o + "cut_copper", "waxed_" + o + "cut_copper_stairs", "waxed_" + o + "cut_copper_slab");
        }
        for (String d : new String[]{"cobbled_deepslate", "polished_deepslate", "deepslate_brick", "deepslate_tile"}) {
            add(V1_17_1, d + "_slab", d + "_stairs", d + "_wall");
        }

        // ---------------- 1.18 ----------------
        add(V1_18_2, "music_disc_otherside");

        // ---------------- 1.19 ----------------
        add(V1_19_2, "mud", "packed_mud", "mud_bricks", "mud_brick_slab", "mud_brick_stairs", "mud_brick_wall", "sculk",
                "sculk_catalyst", "sculk_shrieker", "sculk_vein", "reinforced_deepslate", "ochre_froglight",
                "verdant_froglight", "pearlescent_froglight", "frogspawn", "echo_shard", "recovery_compass",
                "disc_fragment_5", "music_disc_5", "goat_horn", "allay_spawn_egg", "frog_spawn_egg", "tadpole_spawn_egg",
                "warden_spawn_egg", "tadpole_bucket", "mangrove_log", "mangrove_wood", "stripped_mangrove_log",
                "stripped_mangrove_wood", "mangrove_planks", "mangrove_leaves", "mangrove_propagule", "mangrove_roots",
                "muddy_mangrove_roots", "mangrove_slab", "mangrove_stairs", "mangrove_fence", "mangrove_fence_gate",
                "mangrove_door", "mangrove_trapdoor", "mangrove_button", "mangrove_pressure_plate", "mangrove_sign",
                "mangrove_boat", "mangrove_chest_boat", "oak_chest_boat", "spruce_chest_boat", "birch_chest_boat",
                "jungle_chest_boat", "acacia_chest_boat", "dark_oak_chest_boat");

        // ---------------- 1.19.3 - 1.20.1 ----------------
        add(V1_20_1, "cherry_log", "cherry_wood", "stripped_cherry_log", "stripped_cherry_wood", "cherry_planks",
                "cherry_leaves", "cherry_sapling", "cherry_slab", "cherry_stairs", "cherry_fence", "cherry_fence_gate",
                "cherry_door", "cherry_trapdoor", "cherry_button", "cherry_pressure_plate", "cherry_sign", "cherry_boat",
                "cherry_chest_boat", "pink_petals", "bamboo_block", "stripped_bamboo_block", "bamboo_planks",
                "bamboo_mosaic", "bamboo_slab", "bamboo_stairs", "bamboo_mosaic_slab", "bamboo_mosaic_stairs",
                "bamboo_fence", "bamboo_fence_gate", "bamboo_door", "bamboo_trapdoor", "bamboo_button",
                "bamboo_pressure_plate", "bamboo_sign", "bamboo_raft", "bamboo_chest_raft", "chiseled_bookshelf",
                "decorated_pot", "suspicious_sand", "brush", "torchflower", "torchflower_seeds",
                "pitcher_plant", "pitcher_pod", "sniffer_egg", "sniffer_spawn_egg", "camel_spawn_egg",
                "calibrated_sculk_sensor", "music_disc_relic", "piglin_head", "netherite_upgrade_smithing_template");
        for (String w : new String[]{"oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry",
                "bamboo", "crimson", "warped"}) {
            add(V1_20_1, w + "_hanging_sign");
        }
        for (String t : new String[]{"coast", "dune", "eye", "host", "raiser", "rib", "sentry", "shaper", "silence",
                "snout", "spire", "tide", "vex", "ward", "wayfinder", "wild"}) {
            add(V1_20_1, t + "_armor_trim_smithing_template");
        }
        for (String s : new String[]{"angler", "archer", "arms_up", "blade", "brewer", "burn", "danger", "explorer",
                "friend", "heart", "heartbreak", "howl", "miner", "mourner", "plenty", "prize", "sheaf", "shelter",
                "skull", "snort"}) {
            add(V1_20_1, s + "_pottery_sherd");
        }
    }

    private ItemRules() {}

    private static void refresh() {
        List<? extends String> raw = VSConfig.ITEM_RULES.get();
        if (raw != lastRaw) {
            lastRaw = raw;
            overrides = VSConfig.parseRules(raw);
            CACHE.clear();
        }
    }

    /** The first version in which the item exists. */
    public static GameVersion firstVersion(Item item) {
        refresh();
        GameVersion cached = CACHE.get(item);
        if (cached != null) return cached;
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
        GameVersion result = OLDEST;
        if (key != null) {
            String full = key.toString().toLowerCase(Locale.ROOT);
            GameVersion v = overrides.get(full);
            if (v == null) v = overrides.get(key.getNamespace().toLowerCase(Locale.ROOT) + ":*");
            if (v == null && key.getNamespace().equals("minecraft")) v = BUILTIN.get(key.getPath());
            if (v != null) result = v;
        }
        CACHE.put(item, result);
        return result;
    }

    public static boolean isAvailable(ItemStack stack, GameVersion version) {
        return stack.isEmpty() || !firstVersion(stack.getItem()).isNewerThan(version);
    }
}
