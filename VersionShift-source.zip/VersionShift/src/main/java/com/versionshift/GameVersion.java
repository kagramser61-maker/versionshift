package com.versionshift;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Versions the mod jumps between. A larger ordinal means a newer version. */
public enum GameVersion {
    V1_7_10("1.7.10"),
    V1_8_9("1.8.9"),
    V1_9_4("1.9.4"),
    V1_10_2("1.10.2"),
    V1_11_2("1.11.2"),
    V1_12_2("1.12.2"),
    V1_13_2("1.13.2"),
    V1_14_4("1.14.4"),
    V1_15_2("1.15.2"),
    V1_16_5("1.16.5"),
    V1_17_1("1.17.1"),
    V1_18_2("1.18.2"),
    V1_19_2("1.19.2"),
    V1_20_1("1.20.1");

    public static final GameVersion OLDEST = V1_7_10;
    public static final GameVersion LATEST = V1_20_1;

    private final String id;

    GameVersion(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public boolean isNewerThan(GameVersion other) {
        return compareTo(other) > 0;
    }

    /** Returns null when the id is unknown. */
    public static GameVersion byId(String id) {
        if (id == null) return null;
        String s = id.trim().toLowerCase(Locale.ROOT);
        for (GameVersion v : values()) {
            if (v.id.equals(s)) return v;
        }
        return null;
    }

    public static List<String> ids() {
        List<String> list = new ArrayList<>();
        for (GameVersion v : values()) list.add(v.id);
        return list;
    }
}
