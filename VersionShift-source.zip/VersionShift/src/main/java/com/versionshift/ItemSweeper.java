package com.versionshift;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public final class ItemSweeper {
    private ItemSweeper() {}

    /** Deletes stacks that do not exist in the given version. Returns how many stacks were removed. */
    public static int sweep(ServerPlayer player, GameVersion version) {
        ItemScope scope = VSConfig.ITEM_SCOPE.get();
        Inventory inv = player.getInventory();
        int removed = 0;

        if (scope == ItemScope.HANDS) {
            removed += clearSlot(inv, inv.selected, version);                         // main hand
            removed += clearSlot(inv, inv.items.size() + inv.armor.size(), version);  // off hand
        } else {
            for (int i = 0; i < inv.getContainerSize(); i++) {
                removed += clearSlot(inv, i, version);
            }
        }

        // the item "stuck" to the mouse cursor
        ItemStack carried = player.containerMenu.getCarried();
        if (!ItemRules.isAvailable(carried, version)) {
            player.containerMenu.setCarried(ItemStack.EMPTY);
            removed++;
        }

        if (scope == ItemScope.INVENTORY_AND_ENDER_CHEST) {
            Container ender = player.getEnderChestInventory();
            for (int i = 0; i < ender.getContainerSize(); i++) {
                removed += clearSlot(ender, i, version);
            }
        }

        if (removed > 0) {
            player.containerMenu.broadcastChanges();
            player.inventoryMenu.broadcastChanges();
        }
        return removed;
    }

    private static int clearSlot(Container container, int slot, GameVersion version) {
        ItemStack stack = container.getItem(slot);
        if (ItemRules.isAvailable(stack, version)) return 0;
        container.setItem(slot, ItemStack.EMPTY);
        return 1;
    }
}
