package com.versionshift;

import com.versionshift.network.Net;
import com.versionshift.network.VersionSyncPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class VersionManager {
    private VersionManager() {}

    /** Versions from the config (valid, distinct). Falls back to all versions if fewer than two are given. */
    public static List<GameVersion> rotation() {
        List<GameVersion> list = new ArrayList<>();
        for (String id : VSConfig.VERSIONS.get()) {
            GameVersion v = GameVersion.byId(id);
            if (v != null && !list.contains(v)) list.add(v);
        }
        if (list.size() < 2) {
            list.clear();
            for (GameVersion v : GameVersion.values()) list.add(v);
        }
        return list;
    }

    /** Random version that differs from the current one. */
    public static GameVersion pickNext(GameVersion current) {
        List<GameVersion> candidates = new ArrayList<>(rotation());
        candidates.remove(current);
        return candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
    }

    public static VersionSyncPacket packet(VersionSavedData data) {
        int ticks = data.ticksLeft < 0 ? VSConfig.intervalTicks() : data.ticksLeft;
        return new VersionSyncPacket(data.current.id(), ticks, data.paused);
    }

    public static void syncAll(MinecraftServer server, VersionSavedData data) {
        Net.sendToAll(packet(data));
    }

    /** Called every server tick (end phase). */
    public static void tick(MinecraftServer server) {
        VersionSavedData data = VersionSavedData.get(server);
        int interval = VSConfig.intervalTicks();
        if (data.ticksLeft < 0 || data.ticksLeft > interval) {
            data.ticksLeft = interval;
            data.setDirty();
        }
        if (server.getPlayerCount() == 0) return; // the clock only runs while somebody is playing

        if (!data.paused) {
            data.ticksLeft--;
            if (data.ticksLeft <= 0) {
                switchTo(server, pickNext(data.current));
                return;
            }
            if (data.ticksLeft % 200 == 0) syncAll(server, data); // keeps client countdowns accurate
        }

        if (server.getTickCount() % 20 == 0) {
            data.setDirty();
            boolean sweep = VSConfig.KEEP_SWEEPING.get();
            for (ServerPlayer player : new ArrayList<>(server.getPlayerList().getPlayers())) {
                if (sweep) {
                    int removed = ItemSweeper.sweep(player, data.current);
                    if (removed > 0) notifyRemoved(player, removed, data.current, false);
                }
                checkDimension(player, data.current);
            }
        }
    }

    /** Switches the whole game to the given version right now and restarts the timer. */
    public static void switchTo(MinecraftServer server, GameVersion target) {
        VersionSavedData data = VersionSavedData.get(server);
        data.current = target;
        data.ticksLeft = VSConfig.intervalTicks();
        data.setDirty();

        syncAll(server, data);
        for (ServerPlayer player : new ArrayList<>(server.getPlayerList().getPlayers())) {
            player.sendSystemMessage(Component.translatable("versionshift.switched", target.id())
                    .withStyle(ChatFormatting.GOLD));
            int removed = ItemSweeper.sweep(player, target);
            if (removed > 0) notifyRemoved(player, removed, target, true);
            checkDimension(player, target);
        }
        VersionShiftMod.LOGGER.info("Game version switched to {}", target.id());
    }

    public static void onPlayerJoin(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        VersionSavedData data = VersionSavedData.get(server);
        Net.sendTo(player, packet(data));
        player.sendSystemMessage(Component.translatable("versionshift.switched", data.current.id())
                .withStyle(ChatFormatting.GOLD));
        int removed = ItemSweeper.sweep(player, data.current);
        if (removed > 0) notifyRemoved(player, removed, data.current, true);
        // the dimension is checked by the once-per-second pass
    }

    private static void notifyRemoved(ServerPlayer player, int removed, GameVersion version, boolean chat) {
        if (!VSConfig.NOTIFY.get()) return;
        Component msg = Component.translatable("versionshift.items_vanished", removed, version.id())
                .withStyle(ChatFormatting.RED);
        if (chat) player.sendSystemMessage(msg);
        else player.displayClientMessage(msg, true);
    }

    /** If the player stands in a dimension that does not exist in this version, send them to the Overworld. */
    public static void checkDimension(ServerPlayer player, GameVersion version) {
        if (DimensionRules.isAllowed(player.level().dimension(), version)) return;
        MinecraftServer server = player.getServer();
        if (server == null) return;

        ServerLevel overworld = server.overworld();
        BlockPos spawn = overworld.getSharedSpawnPos();
        BlockPos top = overworld.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn);
        player.teleportTo(overworld, top.getX() + 0.5, top.getY() + 0.1, top.getZ() + 0.5,
                player.getYRot(), player.getXRot());
        player.sendSystemMessage(Component.translatable("versionshift.dimension_gone", version.id())
                .withStyle(ChatFormatting.YELLOW));
    }
}
