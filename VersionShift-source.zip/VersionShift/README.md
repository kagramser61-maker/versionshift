# Version Shift (Forge 1.20.1)

Каждые 5 минут «версия игры» случайно меняется между 1.7.10 и 1.20.1:

* **Текстуры** — для версий до 1.13.2 включается старый вид (встроенный пак Programmer Art), для 1.14+ — обычные.
* **Предметы** — если предмета не было в текущей версии, он исчезает (из инвентаря, рук и курсора) и его нельзя подобрать/получить.
* **Измерения** — если игрок в измерении, которого нет в этой версии, его телепортирует в Верхний мир.

## Сборка .jar

Нужны JDK 17 и Gradle 8.1.1 (или любая 8.x).

    gradle build

Готовый файл: `build/libs/versionshift-1.0.0.jar` → положить в папку `mods` (Minecraft 1.20.1, Forge 47.2.0+).
Мод нужен и на клиенте, и на сервере.

Без установки чего-либо: загрузить проект в репозиторий на GitHub → вкладка **Actions** → **build** → скачать артефакт `versionshift-jar`.

## Команды

* `/versionshift` — текущая версия и время до смены
* `/versionshift set <версия>` — сменить сразу (нужен оп, уровень 2)
* `/versionshift next` — случайная следующая версия
* `/versionshift pause` / `resume` — остановить / запустить таймер

## Настройки

`config/versionshift-common.toml` (сервер):
`intervalSeconds`, `versions`, `itemScope` (HANDS / INVENTORY / INVENTORY_AND_ENDER_CHEST), `keepSweeping`,
`blockPickup`, `notify`, `itemRules`, `dimensionRules`.

`config/versionshift-client.toml` (клиент):
`swapTextures`, `showHud`, `legacyUpToVersion`, `legacyPack`, `packRules`.

### Свои текстуры для конкретной версии

Положи пак (zip) в папку `resourcepacks` и добавь правило, например:

    packRules = ["1.7.10=file/OldTextures-1.7.10.zip", "1.12.2=file/Textures-1.12.zip"]

### Измерения из других модов

В ванильном Minecraft Верхний мир, Нижний мир и Энд есть во всех версиях начиная с 1.7.10, поэтому ванильные
измерения никого не выкидывают. Для модовых измерений задай, с какой версии они существуют:

    dimensionRules = ["twilightforest:twilight_forest=1.7.10"]

### Предметы из других модов

    itemRules = ["somemod:cool_item=1.12.2", "somemod:*=1.10.2"]
