package com.versionshift.client;

import com.versionshift.GameVersion;
import com.versionshift.VSConfig;
import com.versionshift.VersionShiftMod;
import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.repository.PackRepository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Swaps the active resource pack to match the current game version.
 * Versions up to "legacyUpToVersion" use the legacy pack (Programmer Art by default), newer ones use vanilla textures.
 * "packRules" can assign any pack from the resourcepacks folder to any version.
 * A resource reload only happens when the effective pack actually changes.
 */
public final class TextureSwitcher {
    /** Pack selection the player had before the mod touched it. */
    private static List<String> original = null;
    /** Pack applied for the current world ("" = none). Null = not applied yet. */
    private static String applied = null;
    private static final Set<String> warned = new HashSet<>();

    private TextureSwitcher() {}

    public static void update(GameVersion version) {
        if (!VSConfig.SWAP_TEXTURES.get()) {
            revert();
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        PackRepository repo = mc.getResourcePackRepository();
        if (original == null) original = new ArrayList<>(repo.getSelectedIds());

        String wanted = resolve(repo, wantedPack(version));
        if (wanted.equals(applied)) return; // already in place (also covers the periodic re-syncs)
        boolean first = applied == null;
        applied = wanted;

        List<String> target = new ArrayList<>(original);
        target.removeAll(controlled(repo));
        if (!wanted.isEmpty()) target.add(wanted); // last = highest priority

        if (first && new ArrayList<>(repo.getSelectedIds()).equals(target)) return; // nothing to change
        repo.setSelected(target);
        mc.reloadResourcePacks();
    }

    /** Puts the player's own resource pack selection back. */
    public static void revert() {
        List<String> restore = original;
        original = null;
        applied = null;
        if (restore == null) return;
        Minecraft mc = Minecraft.getInstance();
        PackRepository repo = mc.getResourcePackRepository();
        if (new ArrayList<>(repo.getSelectedIds()).equals(restore)) return;
        repo.setSelected(restore);
        mc.reloadResourcePacks();
    }

    private static String wantedPack(GameVersion version) {
        for (String entry : VSConfig.PACK_RULES.get()) {
            int eq = entry.indexOf('=');
            if (eq <= 0) continue;
            if (GameVersion.byId(entry.substring(0, eq)) == version) return entry.substring(eq + 1).trim();
        }
        GameVersion legacyMax = GameVersion.byId(VSConfig.LEGACY_MAX_VERSION.get());
        if (legacyMax == null) legacyMax = GameVersion.V1_13_2;
        return version.compareTo(legacyMax) <= 0 ? VSConfig.LEGACY_PACK.get().trim() : "";
    }

    /** All packs this mod may switch on or off. */
    private static Set<String> controlled(PackRepository repo) {
        Set<String> set = new HashSet<>();
        String legacy = resolve(repo, VSConfig.LEGACY_PACK.get().trim());
        if (!legacy.isEmpty()) set.add(legacy);
        for (String entry : VSConfig.PACK_RULES.get()) {
            int eq = entry.indexOf('=');
            if (eq <= 0) continue;
            String pack = resolve(repo, entry.substring(eq + 1).trim());
            if (!pack.isEmpty()) set.add(pack);
        }
        return set;
    }

    /** Finds the real pack id in the repository. Returns "" if there is no such pack. */
    private static String resolve(PackRepository repo, String name) {
        if (name == null || name.isEmpty()) return "";
        Collection<String> available = repo.getAvailableIds();
        if (available.contains(name)) return name;

        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.contains("programmer") || lower.contains("programer")) { // spelling differs between versions
            for (String id : available) {
                String l = id.toLowerCase(Locale.ROOT);
                if (l.contains("programmer_art") || l.contains("programer_art")) return id;
            }
        }
        if (warned.add(name)) {
            VersionShiftMod.LOGGER.warn("Version Shift: resource pack '{}' was not found. Available: {}", name, available);
        }
        return "";
    }
}
