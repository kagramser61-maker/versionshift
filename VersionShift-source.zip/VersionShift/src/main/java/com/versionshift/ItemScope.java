package com.versionshift;

/** Where "future" items are removed from when the version goes back in time. */
public enum ItemScope {
    /** Main hand, off hand and the item on the mouse cursor. */
    HANDS,
    /** Whole player inventory (hotbar, backpack, armor, off hand, cursor). */
    INVENTORY,
    /** Inventory plus the player's ender chest. */
    INVENTORY_AND_ENDER_CHEST
}
